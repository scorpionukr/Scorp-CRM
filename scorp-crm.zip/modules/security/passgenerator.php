<?php
if (isset($_POST["codepass"])) {
    $upasswd = filter_input(INPUT_POST, "codepass", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    // Генерируем соль
    $salt = '$2a$10$' . substr(str_replace('+', '.', base64_encode(pack('N4', mt_rand(), mt_rand(), mt_rand(), mt_rand()))), 0, 22) . '$';
    // Шифруем пароль с применением данной соли
    $hashedPasswd = crypt($upasswd, $salt);
}
if(isset($_POST["zalogin"])) {
    $hash = filter_input(INPUT_POST, "zalogin", FILTER_SANITIZE_FULL_SPECIAL_CHARS); 
    $password = "12345";    

    if (check_password($hash, $password)) {  
	echo "Доступ разрешён!";  
    }
    else {  
	echo "Доступ запрещён!";  
    }
    
}
function check_password($hash, $password) {  
	// первые 29 символов хеша, включая алгоритм, «силу замедления» и оригинальную «соль» поместим в переменную  $full_salt
	$full_salt = substr($hash, 0, 29);   
	// выполним хеш-функцию для переменной $password  
	$new_hash = crypt($password, $full_salt);   
	// возвращаем результат («истина» или «ложь»)  
	return ($hash == $new_hash);
    }
?>
<html lang="ru">
    <head>
	<title>кодировщик паролей</title>
	<meta charset="utf-8">
    </head>
    <body>
	<form method="POST" name="coder" action="passgenerator.php">
	    Введите пароль: <input type="text" name="codepass" value="" /><br />
	    <input type="submit" name="code" value="Закодировать" /><br />
	</form>
	<br />
	<?
	if (isset($_POST["codepass"])) {
	    echo "Пароль: " . $_POST["codepass"] . "<br />";
	    echo "Хеш пароль: " . $hashedPasswd;
	}
	?>
	<br />
	<br />
	<br />
	<br />
	<form method="POST" name="test" action="passgenerator.php">
	    Введите пароль: <input type="text" name="zalogin" value="" style="width: 200px;" /><br />
	    <input type="submit" name="zacode" value="Проверить вход" /><br />
	</form>
    </body>
</html>