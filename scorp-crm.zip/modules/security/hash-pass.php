<?php
// hash-pass.php
// родитель 
// файл шифрования алгоритма шифрования паролей
// Генерируем соль
$salt = '$2a$10$' . substr(str_replace('+', '.', base64_encode(pack('N4', mt_rand(), mt_rand(), mt_rand(), mt_rand()))), 0, 22) . '$';
// Шифруем пароль с применением данной соли
$hashedPasswd = crypt($upasswd, $salt);
