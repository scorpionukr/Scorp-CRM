<?php
// check-pass.php
// родитель index.php
// подключаемый файл для проверки пароля CRM
function check_password($hash, $password) {
    $full_salt = substr($hash, 0, 29);
    // выполним хеш-функцию для переменной $password  
    $new_hash = crypt($password, $full_salt);
    // возвращаем результат («истина» или «ложь»)  
    return ($hash == $new_hash);
}