<!-- Добро пожаловать -->
	    <div class="container">
		<div class="row">
		    <div class="col-md-2">
		    </div>
		    <div class="col-md-8">
			<h1 class="violet">Добро пожаловать в <strong><? echo $rowNameCrm["crm-name"]; ?></strong></h1>
		    </div>
		    <div class="col-md-2">
		    </div>
		</div>
	    </div>
