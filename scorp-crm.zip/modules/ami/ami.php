<?php

require "AsteriskManager.php";
// создаем массив с данными о подключении
$params = array('server' => '192.168.3.101', 'port' => '5038');

// создаем екземпляр класса
$ast = new Net_AsteriskManager($params);

/**
 * Connect to server
 */
try {
    $ast->connect();
}
catch (PEAR_Exception $e) {
    echo $e;
}

/**
 * Login to manager API
 */
try {
    $ast->login('admin', 'amp111');
} catch (PEAR_Exception $e) {
    echo $e;
}

/**
 * Monitoring
 * Begin monitoring channel to filename "test.gsm"
 * If it fails then echo Asterisk error
 */
$chan = 'SIP/101';

try {
    $ast->startMonitor($chan, 'test', 'gsm', 1);
} catch (PEAR_Exception $e) {
    echo $e;
}

