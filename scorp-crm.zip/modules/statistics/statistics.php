<?php
// statistcs.php
// родитель main.php
// подключаемый основной файл модуля Статистики
// в целях безопасности в нем не стартуется сессия.
?>
<!-- INCOMING -->
<div class="container-fluid">
    <div class="row" id="incoming-anketa">
	<div class="col-md-8" id="widget-1">
	    <?
	    if($widget[1][0]==1) {
		include_once("modules/".$_GET["module"]."/".$widget[1][1]."/".$widget[1][1].".php"); 
	    }
	    ?>
	    <div class="panel panel-info">
		<div class="panel-heading"></div>
		<div class="panel-body">
		    основной виджет модуля статистики.<br />
		</div>
	    </div>
	</div>
	<div class="col-md-4">
	    <div class="col-md-12" id="widget-2">
		<?
		if($widget[2][0]==2) {
		    include_once("modules/".$_GET["module"]."/".$widget[2][1]."/".$widget[2][1].".php");
		}
		?>
		<div class="panel panel-info">
		    <div class="panel-heading"></div>
		    <div class="panel-body">
			дополнительный виджет 2 модуля статистики.<br />
		    </div>
		</div>
	    </div>
	    <div class="col-md-12" id="widget-3">
		<?
		if($widget[3][0]==3) {
		    include_once("modules/".$_GET["module"]."/".$widget[3][1]."/".$widget[3][1].".php"); 
		}
		?>
		<div class="panel panel-info">
		    <div class="panel-heading"></div>
		    <div class="panel-body">
			дополнительный виджет 3 модуля статистики.<br />
		    </div>
		</div>
	    </div>
	    <div class="col-md-12" id="widget-4">
		<?
		if($widget[4][0]==4) {
		    include_once("modules/".$_GET["module"]."/".$widget[4][1]."/".$widget[4][1].".php"); 
		}
		?>
		<div class="panel panel-info">
		    <div class="panel-heading"></div>
		    <div class="panel-body">
			дополнительный виджет 4 модуля статистики.<br />
		    </div>
		</div>
	    </div>
	</div>
    </div>
    <div class="row block-hidden" id="submit-ok">
	<div class="col-md-4"></div>
	<div class="col-md-4">
	    <div class="panel panel-info">
		<div class="panel-heading"></div>
		<div class="panel-body">
		    Анкета успешно сохранена.<br />
		    <a href="/index.php?module=calls&vector=incoming">Открыть новую анкету</a><br />
		</div>
	    </div>
	    <div class="col-md-4"></div>
	</div>
    </div>
</div>