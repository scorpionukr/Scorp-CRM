<?
// callshistory.php
// виджет вывода поступивших в проект звонков модуля Входящей линии
?>
	    <div id="callsproject">
	    </div>