<?php
// queryhistory.php
// родитель callshistory.php
// вывод таблицу звонков поступивших в проект
// стартуем сессию
session_start();
if (!isset($_SESSION["login"])) {
    $_SESSION["login"] = false;
    exit();
} elseif ($_SESSION["login"] == false) {
    header("Location: /index.php");
} else {
    // если пользователь залогинен исполняем скрипт
    // подключаем библиотеку конфига
    include_once("../../../configs/config.php");
    //екранируем переменные
    $pid = filter_input(INPUT_POST, "pid", FILTER_SANITIZE_NUMBER_INT);
    // Вынимаем из БД звонки по проекту
    $selIncProject = "SELECT `id`, `calldate`, `calltime`, `phone`, `advphone`, `fio`, `company`, `theme`, `comment`, `city`, `status` FROM `incoming` WHERE `pid`='" . $pid . "' ORDER BY `id` DESC LIMIT 10";
    $resIncProject = $dbc->query($selIncProject) or die("Ошибка выборки звонков в callsincproject.php");
    while ($rowIncProject = mysqli_fetch_array($resIncProject)) {
	switch ($rowIncProject["status"]) {
	    case "Консультация":
		$style = "info";
		break;
	    case "Заказ":
		$style = "success";
		break;
	    case "Жалоба":
		$style = "danger";
		break;
	    case "Перезвонить":
		$style = "warning";
		break;
	    default:
		$style = "default";
	}
	?>
	<div class="panel panel-<? echo $style; ?>">
	    <div class="panel-heading">#<? echo $rowIncProject["id"] . " - " . $rowIncProject["status"]; ?></div>
	    <div class="panel-body">
		<div class="col-xs-6">
		    <b>Ф.И.О.: </b><? echo $rowIncProject["fio"]; ?><br />
		    <b>Телефон: </b><? echo $rowIncProject["phone"]; ?><br />
		    <b>Доп. телефон: </b><? echo $rowIncProject["advphone"]; ?><br />
		    <b>Компания: </b><? echo $rowIncProject["company"]; ?><br />
		</div>
		<div class="col-xs-6">
		    <b>Тема разговора: </b><? echo $rowIncProject["theme"]; ?><br />
		    <b>Комментарий: </b><br />
		    <? echo $rowIncProject["comment"]; ?>
		</div>
	    </div>
	</div>
	<?
    }
}