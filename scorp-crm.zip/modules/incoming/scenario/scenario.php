<?php
// scenario.php
// виджет вывода сценария проекта для модуля Входящей линии
?>
<div id="scenario">
</div>