<?php
// queryscenario.php
// родитель scenario.php
// вывод сценариев проекта
// стартуем сессию
session_start();
if (!isset($_SESSION["login"])) {
    $_SESSION["login"] = false;
    exit();
} elseif ($_SESSION["login"] == false) {
    header("Location: /index.php");
} else {
    // если пользователь залогинен исполняем скрипт
    // подключаем библиотеку конфига
    include_once("../../../configs/config.php");
    //екранируем переменные
    $pid = filter_input(INPUT_POST, "pid", FILTER_SANITIZE_NUMBER_INT);
    // достаем вкладки сценариев
    $selScenarioTab="SELECT `name` FROM `scenario` WHERE `pid`='".$pid."' ORDER BY `id` ASC";
    $resScenarioTab=$dbc->query($selScenarioTab) or die("Ошибка выборки в queryscenario.php");
    // счетчик
    $count=1;
    ?>
    <ul class="nav nav-tabs nav-justified">
    <?
    while ($rowScenarioTab = mysqli_fetch_array($resScenarioTab)) {
	if($count==1) {
	    
	?>
	    <li role="presentation" class="scenat active" id="scentab<? echo $count; ?>"><a href="#" onClick="scenarioTabs('scentab<? echo $count; ?>', 'scen<? echo $count; ?>', 'scenat', 'scena');"><? echo $rowScenarioTab["name"]; ?></a></li>
	<?
	}
	else {
	    ?>
	    <li role="presentation" class="scenat" id="scentab<? echo $count; ?>"><a href="#" onClick="scenarioTabs('scentab<? echo $count; ?>', 'scen<? echo $count; ?>', 'scenat', 'scena');"><? echo $rowScenarioTab["name"]; ?></a></li>
	<?
	}
	++$count;
    }
    ?>
    </ul>
    <?
    // достаем сами сценарии
    $selScenario="SELECT `content` FROM `scenario` WHERE `pid`='".$pid."' ORDER BY `id` ASC";
    $resScenario=$dbc->query($selScenario) or die("Ошибка выборки в queryscenario.php");
    // обнуляем счетчик
    $count=1;
    while ($rowScenario = mysqli_fetch_array($resScenario)) {
	if($count==1) {
	    ?>
	    <div class="well scena" id="scen<? echo $count; ?>">
		<? echo $rowScenario["content"]; ?>
	    </div>
	    <?
	}
	else {
	    ?>
	    <div class="well scena block-hidden" id="scen<? echo $count; ?>">
		<? echo $rowScenario["content"]; ?>
	    </div>
	    <?
	}
	++$count;
    }
}