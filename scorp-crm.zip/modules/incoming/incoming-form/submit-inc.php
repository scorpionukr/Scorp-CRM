<?php
// submit-inc.php
// родитель incoming-form.php
// сохранение анкеты входящего звонка
// стартуем сессию
session_start();
if (!isset($_SESSION["login"])) {
    $_SESSION["login"] = false;
    exit();
} elseif ($_SESSION["login"] == false) {
    header("Location: /index.php");
} else {
    // если пользователь залогинен исполняем скрипт
    // подключаем библиотеку конфига
    include_once("../../../configs/config.php");
    //екранируем переменные
    $project = filter_input(INPUT_POST, "project", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $tel = filter_input(INPUT_POST, "tel", FILTER_SANITIZE_NUMBER_INT);
    $advtel = filter_input(INPUT_POST, "advtel", FILTER_SANITIZE_NUMBER_INT);
    $theme = filter_input(INPUT_POST, "theme", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $fio = filter_input(INPUT_POST, "fio", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $org = filter_input(INPUT_POST, "org", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $city = filter_input(INPUT_POST, "city", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $status = filter_input(INPUT_POST, "status", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $comment = filter_input(INPUT_POST, "comment", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $data = filter_input(INPUT_POST, "data", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $time = filter_input(INPUT_POST, "time", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    // Узнаем в АТС uniqueid чтобы связать записи CRM с АТС
    $selUniqueid = "SELECT `uniqueid` FROM `cdr` WHERE `src`='" . $tel . "' AND `dst`='" . $_SESSION["sip"] . "' ORDER BY `calldate` LIMIT 1";
    $resUniqueid = $dbca->query($selUniqueid) or die("Ошибка выборки uniqueid из Астериск в submit-inc.php");
    $rowUniqueid = mysqli_fetch_array($resUniqueid);
    // Сохраняем данные в БД
    $insAnketa = "INSERT INTO `incoming` (`uniqueid`, `calldate`, `calltime`, `pid`, `uid`, `phone`, `advphone`, `fio`, `company`, `theme`, `comment`, `city`, `status`) "
	    . "VALUES "
	    . "('" . $rowUniqueid["uniqueid"] . "', '" . $data . "', '" . $time . "', '" . $project . "', '" . $_SESSION["id"] . "', '" . $tel . "', '" . $advtel . "', '" . $fio . "', '" . $org . "', '" . $theme . "', '" . $comment . "', '" . $city . "', '" . $status . "')";
    $queryAnketa = $dbc->query($insAnketa) or die("Ошибка сохранения анкеты в submit-inc.php");
    // закрываем подключение к БД
    mysqli_close($dbc);
    mysqli_close($dbca);
}

