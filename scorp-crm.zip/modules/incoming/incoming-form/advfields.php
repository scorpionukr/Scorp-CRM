<?php
// advfields.php
// родитель incoming-form.php
// вывод дополнительных полей анкеты проекта
// стартуем сессию
session_start();
if (!isset($_SESSION["login"])) {
    $_SESSION["login"] = false;
    exit();
} elseif ($_SESSION["login"] == false) {
    header("Location: /index.php");
} else {
    // если пользователь залогинен исполняем скрипт
    // подключаем библиотеку конфига
    include_once("../../../configs/config.php");
    //екранируем переменные
    $pid = filter_input(INPUT_POST, "pid", FILTER_SANITIZE_NUMBER_INT);
    // достаем дополнительные поля
    $selAdvFields="SELECT `type`, `text`, `name` FROM `advfields` WHERE `pid`='".$pid."' AND `active`='1' ORDER BY `position` ASC";
    $resAdvFields=$dbc->query($selAdvFields) or die("Ошибка выбора дополнительных полей в advfields.php" . mysqli_error($dbc));
    while($rowAdvFields=mysqli_fetch_array($resAdvFields)) {
	if($rowAdvFields["type"]=="text") {
	    ?>
	    <div class="form-group">
		<input type="text" name="<? echo $rowAdvFields["name"]; ?>" class="form-control" placeholder="<? echo $rowAdvFields["text"]; ?>" />
	    </div>
	    <?
	}
	elseif($rowAdvFields["type"]=="select") {
	    ?>
	    <div class="form-group">
		<? echo "select"; ?>
	    </div>
	    <?
	}
	else {
	    ?>
	    <div class="form-group">
		<? echo "Такого типа поля не существует"; ?>
	    </div>
	    <?
	}
    }
}