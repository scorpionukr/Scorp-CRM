<?php
// incoming-form.php
// виджет формы анкеты модуля Входящей линии
// выбираем проекта пользователя
$selUProject="SELECT `pid` FROM `uprojects` WHERE `uid`='".$_SESSION["id"]."' AND `type`='1' AND `active`='1'";
$resUProject=$dbc->query($selUProject) or die("Ошибка выбора проектов пользователя в incoming-form.php" . mysqli_error($dbc));
?>
	    <form method="POST" class="form-horizontal" id="incoming-call" action="javascript:void(null);" onSubmit="submitAnk('incoming-call', 'incoming', 'incoming-form', 'submit-inc', 'incoming-anketa', 'submit-ok', 'loader');">
		<div class="form-group">
		    <!-- скрытые поля формы -->
		    <input type="hidden" name="type" class="form-control" value="1" placeholder="Тип звонка" reqiurted />
		    <input type="hidden" name="operator" class="form-control" value="<? echo $_SESSION["id"]; ?>" placeholder="Оператор" reqiurted />
		    <!-- основная часть формы -->
		    <input type="text" name="type-name" class="form-control" value="Входящий звонок" placeholder="Тип звонка" readonly reqiurted />
		</div>
		<div class="form-group">
		    <select name="project" id="prj" class="form-control" onChange="callsProject('prj', 'callsproject', 'incoming', 'callshistory', 'queryhistory'); callsProject('prj', 'scenario', 'incoming', 'scenario', 'queryscenario'); callsProject('prj', 'advancedFields', 'incoming', 'incoming-form', 'advfields');" required>
			<option value="0" disabled selected>Выбирите проект...</option>
			<?
			while($rowUProject=mysqli_fetch_array($resUProject)) {
			    $selProject="SELECT `name`, `queue` FROM `projects` WHERE `id`='".$rowUProject["pid"]."' AND `enable`='1' LIMIT 1";
			    $resProject=$dbc->query($selProject) or die("Ошибка выбора названия и очереди проекта в incoming-form.php" . mysqli_error($dbc));
			    $rowProject=mysqli_fetch_array($resProject);
			?>
			    <option value="<? echo $rowUProject["pid"]; ?>"><? echo $rowProject["name"]; ?></option>
			<?
			}
			?>
		    </select>
		</div>
		<div class="form-group">
		    <input type="text" name="tel" class="form-control" placeholder="Телефон" required />
		</div>
		<div class="form-group">
		    <input type="text" name="advtel" class="form-control" placeholder="Дополнительный телефон" />
		</div>
		<div class="form-group">
		    <input type="text" name="fio" class="form-control" placeholder="Ф.И.О." required />
		</div>
		<div class="form-group">
		    <input type="text" name="org" class="form-control" placeholder="Название компании" />
		</div>
		<div class="form-group">
		    <input type="text" name="city" class="form-control" placeholder="Населенный пункт" required />
		</div>
		<div id="advancedFields">
		</div>
		<div class="form-group">
		    <input type="text" name="theme" class="form-control" placeholder="Тема звонка" />
		</div>
		<div class="form-group">
		    <select name="status" class="form-control" required>
			<option value="" disabled selected>Статус звонка...</option>
			<option value="Не состоялся">Не состоялся</option>
			<option value="Консультация">Консультация</option>
			<option value="Заказ">Заказ</option>
			<option value="Жалоба">Жалоба</option>
			<option value="Переадресация">Переадресация</option>
			<option value="Перезвонить">Перезвонить</option>
		    </select>
		</div>
		<div class="form-group">
		    <textarea name="comment" class="form-control" placeholder="Комментарий к звонку" required></textarea> 
		</div>
		<div class="form-group">
		    <div class="checkbox">
			<label>
			    <input type="checkbox" name="add-contact" value="1">
			    Добавить в список контактов
			</label>
		    </div>
		</div>
		<div class="form-group">
		    <div class="col-xs-4">
			<input type="text" name="data" class="form-control" placeholder="Текущая дата" value="<? echo $curDate; ?>" readonly required />
		    </div>
		    <div class="col-xs-4">
			<input type="text" name="time" class="form-control" placeholder="Текущее время" value="<? echo $curTime; ?>" readonly required />
		    </div>
		    <div class="col-xs-4">
			<input type="text" name="duration" class="form-control" placeholder="Продолжительность звонка" value="1" readonly required />
		    </div>
		</div>
		<div class="form-group">
		    <div class="col-xs-8">
			<button type="submit" class="btn btn-success btn-block">Отправить</button>
		    </div>
		    <div class="col-xs-4">
			<button type="reset" class="btn btn-default btn-block">Очистить</button>
		    </div>
		</div>
	    </form>
