<!DOCTYPE html>
<html lang="ru">
<head>
	<title><? echo $rowNameCrm["crm-name"]; ?></title>
	<meta charset="utf-8">
	<meta name="author" content="<? echo $metaAuthor; ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CSS -->
	<link rel="shortcut icon" href="/images/<? $rowNameCrm["crm-icon"]; ?>">
	<link rel="stylesheet" type="text/css" href="/style/style.css">
	<!-- Bootstrap -->
	<link rel="stylesheet" type="text/css" href="/js/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="/js/bootstrap/css/bootstrap-theme.min.css">
	<!-- JavaScript -->
	<script src="/js/jquery/jquery-1.11.1.min.js"></script>
	<script src="/js/bootstrap/js/bootstrap.min.js"></script>
	<script src="/js/showhide.js"></script>
	<script src="/js/submitank.js"></script>
	<script src="/js/callsproject.js"></script>
	<script src="/js/scenariotabs.js"></script>
	<!-- SIP Phone -->
	<script src="/modules/sip/SIPml-api.js___"></script>
	<script src="/modules/sip/sip-func.js___"></script>
</head>