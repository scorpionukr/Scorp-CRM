function showHide(klacc) {
    $("."+klacc).toggle("fast");
}