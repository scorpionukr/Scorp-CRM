-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Апр 22 2015 г., 16:49
-- Версия сервера: 5.5.43
-- Версия PHP: 5.3.10-1ubuntu3.18

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `scorpio`
--

-- --------------------------------------------------------

--
-- Структура таблицы `advfields`
--

CREATE TABLE IF NOT EXISTS `advfields` (
  `id` int(100) NOT NULL AUTO_INCREMENT COMMENT 'id записи',
  `pid` int(100) DEFAULT NULL COMMENT 'id проекта',
  `position` int(10) DEFAULT NULL COMMENT 'позиция в анкете',
  `type` varchar(100) DEFAULT NULL COMMENT 'тип поля. существуют: text, select',
  `text` varchar(100) DEFAULT NULL COMMENT 'текстовое описание дополнительного поля',
  `name` varchar(100) DEFAULT NULL COMMENT 'имя в  name, тега',
  `active` tinyint(1) DEFAULT NULL COMMENT 'активно, нет?',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `advfields`
--

INSERT INTO `advfields` (`id`, `pid`, `position`, `type`, `text`, `name`, `active`) VALUES
(1, 1, 1, 'text', 'advanced field 1', 'advfield', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `company`
--

CREATE TABLE IF NOT EXISTS `company` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `company`
--

INSERT INTO `company` (`id`, `name`) VALUES
(1, 'Epicall');

-- --------------------------------------------------------

--
-- Структура таблицы `config`
--

CREATE TABLE IF NOT EXISTS `config` (
  `crm-rootdir` varchar(50) NOT NULL COMMENT 'корневая директория CRM',
  `crm-name` varchar(100) NOT NULL COMMENT 'название CRM',
  `crm-logo` varchar(100) NOT NULL COMMENT 'путь где находится логотип CRM',
  `crm-icon` varchar(100) NOT NULL COMMENT 'путь где находится иконка CRM'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `config`
--

INSERT INTO `config` (`crm-rootdir`, `crm-name`, `crm-logo`, `crm-icon`) VALUES
('/', 'Scorpion CRM', 'epicall.png', '');

-- --------------------------------------------------------

--
-- Структура таблицы `incoming`
--

CREATE TABLE IF NOT EXISTS `incoming` (
  `id` int(255) NOT NULL AUTO_INCREMENT COMMENT 'порядковый номер',
  `uniqueid` int(255) DEFAULT NULL COMMENT 'уникальный номер записи в астериск',
  `calldate` date DEFAULT NULL COMMENT 'дата создания анкеты',
  `calltime` time DEFAULT NULL COMMENT 'время создания анкеты',
  `pid` int(30) DEFAULT NULL COMMENT 'номер проекта',
  `uid` int(30) DEFAULT NULL COMMENT 'номер пользователя',
  `phone` varchar(15) DEFAULT NULL COMMENT 'телефон',
  `advphone` varchar(15) DEFAULT NULL COMMENT 'доп. телефон',
  `fio` varchar(100) DEFAULT NULL COMMENT 'фио',
  `company` varchar(100) DEFAULT NULL COMMENT 'название компании',
  `theme` varchar(100) DEFAULT NULL COMMENT 'тема разговора',
  `comment` text COMMENT 'комментарий к разговору',
  `city` varchar(50) DEFAULT NULL COMMENT 'населенный рункт',
  `status` varchar(30) DEFAULT NULL COMMENT 'статус разговора',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `incoming`
--

INSERT INTO `incoming` (`id`, `uniqueid`, `calldate`, `calltime`, `pid`, `uid`, `phone`, `advphone`, `fio`, `company`, `theme`, `comment`, `city`, `status`) VALUES
(1, 111, '2015-05-06', '18:41:00', 1, 1, '0501234567', NULL, 'Scorp', 'SWL', 'development crm', NULL, 'Hell', 'Ð—Ð°ÐºÐ°Ð·'),
(2, 1, '2015-04-07', '11:14:30', 1, 1, '0501234567', '0', 'Ð²ÐµÑ‚Ð°Ð»', 'Ð²Ð²Ð²', 'Ñ‚ÐµÑÑ‚', NULL, 'Ñ…Ð°Ñ€ÑŒÐºÐ¾Ð²', 'ÐšÐ¾Ð½ÑÑƒÐ»ÑŒÑ‚Ð°Ñ†Ð¸Ñ'),
(3, 1, '2015-04-07', '11:20:56', 2, 1, '0501234567', '', 'Ð²ÐµÑ‚Ð°Ð»', 'Ð²Ð²Ð²', 'Ñ‚ÐµÑÑ‚', NULL, 'Ñ…Ð°Ñ€ÑŒÐºÐ¾Ð²', 'ÐšÐ¾Ð½ÑÑƒÐ»ÑŒÑ‚Ð°Ñ†Ð¸Ñ'),
(4, 1, '2015-04-07', '11:27:14', 2, 1, '0501234567', '1234567', 'Ð²ÐµÑ‚Ð°Ð»', 'sdsfsd', 'asdasd', 'hftgjhnfh', 'kiev', 'Ð—Ð°ÐºÐ°Ð·'),
(5, 1, '2015-04-07', '11:35:37', 1, 1, '0501234567', '1234567', 'Ð²ÐµÑ‚Ð°Ð»', 'qwerty', 'Ñ‚ÐµÑÑ‚', 'kliku7mju', 'qwerty', 'Ð–Ð°Ð»Ð¾Ð±Ð°'),
(6, 1, '2015-04-07', '11:38:28', 1, 1, '0501234567', '1234567', 'Ñ„ÐºÑÑ„Ð¹Ð¹', 'sdsfsd', 'asdasd', 'sdfvdsfv', 'kiev', 'ÐšÐ¾Ð½ÑÑƒÐ»ÑŒÑ‚Ð°Ñ†Ð¸Ñ'),
(8, 1, '2015-04-07', '12:33:41', 1, 1, '0501234567', '123456789', 'Ð»ÑÐ»ÑÐ»ÑÐ»ÑÐ»Ñ', 'Scorpion Web Lair', 'Ñ‚ÐµÑÑ‚', 'dfgdfndf', 'Kiev', 'ÐŸÐµÑ€ÐµÐ·Ð²Ð¾Ð½Ð¸Ñ‚ÑŒ'),
(9, 0, '2015-04-08', '12:45:52', 2, 1, '0501234567', '2222', 'Ð’ÐµÑ‚Ð°Ð»Ð»Ð»Ð»', 'Scorpion Web Lair', 'Ñ‚ÐµÑÑ‚', 'fdbrthrntrj', 'Kiev', 'ÐŸÐµÑ€ÐµÐ·Ð²Ð¾Ð½Ð¸Ñ‚ÑŒ'),
(10, 0, '2015-04-08', '15:31:56', 2, 1, '0501234567', '3333', 'Ð’ÐµÑ‚Ð°Ð»Ð»Ð»Ð»', 'Scorpion Web Lair', 'Ð½Ð°Ð·Ð²Ð°Ð½Ð¸Ñ Ð²ÐºÐ»Ð°Ð´Ð¾Ðº', 'Ð’Ñ…Ð¾Ð´ÑÑ‰Ð°Ñ Ð»Ð¸Ð½Ð¸Ñ&#13;&#10;Ð˜ÑÑ…Ð¾Ð´ÑÑ‰Ð°Ñ Ð»Ð¸Ð½Ð¸Ñ&#13;&#10;Ð¡Ñ‚Ð°Ñ‚Ð¸ÑÑ‚Ð¸ÐºÐ°', 'Kiev', 'Ð—Ð°ÐºÐ°Ð·');

-- --------------------------------------------------------

--
-- Структура таблицы `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(255) NOT NULL AUTO_INCREMENT COMMENT 'id проекта',
  `cid` int(255) DEFAULT NULL COMMENT 'id компании которой этот проект принадлежит',
  `name` varchar(100) DEFAULT NULL COMMENT 'название проекта',
  `email` varchar(100) DEFAULT NULL COMMENT 'email на который отправлять уведомления',
  `man-phone` varchar(100) DEFAULT NULL COMMENT 'контактный телефон проекта',
  `queue` int(10) DEFAULT NULL COMMENT 'очередь в астериске',
  `queue-weekend` int(10) DEFAULT NULL COMMENT 'очередь на не рабочее время',
  `enable` tinyint(1) DEFAULT NULL COMMENT 'активен, нет?',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `projects`
--

INSERT INTO `projects` (`id`, `cid`, `name`, `email`, `man-phone`, `queue`, `queue-weekend`, `enable`) VALUES
(1, 1, 'Epicall-Cloud', 'a@a.com', '0501234567', 1000, 1001, 1),
(2, 1, 'Epicall CRM', 'b@b.com', '0507654321', 1002, 1003, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `scenario`
--

CREATE TABLE IF NOT EXISTS `scenario` (
  `id` int(255) NOT NULL AUTO_INCREMENT COMMENT 'id пользователя',
  `pid` int(100) DEFAULT NULL COMMENT 'id проекта',
  `name` varchar(100) DEFAULT NULL COMMENT 'название вкладки',
  `content` text COMMENT 'текст самой вкладки',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `scenario`
--

INSERT INTO `scenario` (`id`, `pid`, `name`, `content`) VALUES
(1, 1, 'Scenario', 'first'),
(2, 1, 'Contacts', 'second'),
(3, 1, 'Other', 'third');

-- --------------------------------------------------------

--
-- Структура таблицы `tabs`
--

CREATE TABLE IF NOT EXISTS `tabs` (
  `id` int(255) NOT NULL AUTO_INCREMENT COMMENT 'id записи',
  `uid` int(100) DEFAULT NULL COMMENT 'id пользователя',
  `tab` varchar(50) DEFAULT NULL COMMENT 'название вкладки',
  `url` varchar(100) DEFAULT NULL COMMENT 'рабочий урл вкладки',
  `active` tinyint(1) DEFAULT NULL COMMENT 'активна, нет?',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `tabs`
--

INSERT INTO `tabs` (`id`, `uid`, `tab`, `url`, `active`) VALUES
(1, 1, 'Incoming calls', '/index.php?module=calls&vector=incoming', 1),
(2, 2, 'Incoming calls', '/index.php?module=calls&vector=incoming', 1),
(4, 1, 'Outgoing calls', '/index.php?module=calls&vector=outgoing', 1),
(5, 1, 'Statistics', '/index.php?module=statistics', 1),
(6, 2, 'Statistics', '/index.php?module=statistics', 1),
(7, 2, 'Outgoing calls', '/index.php?module=calls&vector=outgoing	', 1),
(8, 1, 'Welcome', '/index.php?module=welcome', 1),
(9, 2, 'Welcome', '/index.php?module=welcome', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `uprojects`
--

CREATE TABLE IF NOT EXISTS `uprojects` (
  `id` int(255) NOT NULL AUTO_INCREMENT COMMENT 'id записи',
  `uid` int(100) DEFAULT NULL COMMENT 'id пользователя',
  `pid` int(100) DEFAULT NULL COMMENT 'id проекта',
  `type` smallint(1) DEFAULT NULL COMMENT 'тип проекта. 1 - входящая, 2 - исходящая',
  `active` tinyint(1) DEFAULT NULL COMMENT 'активен, нет?',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `uprojects`
--

INSERT INTO `uprojects` (`id`, `uid`, `pid`, `type`, `active`) VALUES
(1, 1, 1, 1, 1),
(2, 1, 2, 1, 1),
(3, 2, 1, 1, 1),
(4, 2, 2, 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(255) NOT NULL AUTO_INCREMENT COMMENT 'id пользователя',
  `ulogin` varchar(60) DEFAULT NULL COMMENT 'логин пользователя для входа',
  `upasswd` varchar(255) CHARACTER SET cp1250 DEFAULT NULL COMMENT 'пароль пользователя для входа',
  `frst-name` varchar(30) DEFAULT NULL COMMENT 'имя пользователя',
  `lst-name` varchar(30) DEFAULT NULL COMMENT 'фамилия пользователя',
  `sip` int(10) DEFAULT NULL COMMENT 'sip номер',
  `role` varchar(30) DEFAULT NULL COMMENT 'группа пользователя. существует: operator, client, manager, administrator',
  `enable` int(1) DEFAULT '0' COMMENT 'активен, нет?',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `ulogin`, `upasswd`, `frst-name`, `lst-name`, `sip`, `role`, `enable`) VALUES
(1, 'scorpion', '$2a$10$SU.xBHeudg1bevLqMOGjre.WKk4n3rS9RQHcr5qWeCX.473o1WSEa', 'Vetal', 'Bogachev', 102, 'administrator', 1),
(2, 'misha', '$2a$10$SyETJU68/UoF.6GAPSoW/.ZPo22wbrQI2KwJFCp9KYCEL3xVFhCUK', 'Mikhail', NULL, 103, 'administrator', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `users-widgets`
--

CREATE TABLE IF NOT EXISTS `users-widgets` (
  `id` int(255) NOT NULL AUTO_INCREMENT COMMENT 'id записи',
  `uid` int(100) DEFAULT NULL COMMENT 'id пользователя',
  `module` varchar(50) DEFAULT NULL COMMENT 'модуль в котором будет отображатся виджет',
  `position` int(10) DEFAULT NULL COMMENT 'позиция виджета в модуле',
  `widget` varchar(50) DEFAULT NULL COMMENT 'название виджета',
  `active` tinyint(1) DEFAULT NULL COMMENT 'активен, нет?',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `users-widgets`
--

INSERT INTO `users-widgets` (`id`, `uid`, `module`, `position`, `widget`, `active`) VALUES
(1, 1, 'incoming', 2, 'incoming-form', 1),
(2, 1, 'incoming', 3, 'callshistory', 1),
(3, 2, 'incoming', 2, 'incoming-form', 1),
(4, 2, 'incoming', 3, 'callshistory', 1),
(5, 1, 'incoming', 1, 'scenario', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
